#include "flash_defines.h"
#include "driverlib.h"
#include "device.h"
#include "board.h"
#include "F28x_Project.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include <math.h>
#include <shared.h>
#include "drv8323.h"
#include "structs.h"
#include "fsm.h"
#include "foc.h"
#include "user_config.h"
#include "hw_config.h"
#include "F021_F2837xD_C28x.h"


#define ramFuncSection ".TI.ramfunc"

void readBufferFromFlash(uint32_t address_offset,uint16_t* buffer, uint32_t buffer_length);

void writeBufferToFlash(uint32_t address_offset,uint16_t* buffer, uint32_t buffer_length);
