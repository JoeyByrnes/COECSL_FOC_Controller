#include "flash_defines.h"


#define ramFuncSection ".TI.ramfunc"

#pragma CODE_SECTION(Example_CallFlashAPI,ramFuncSection);
void Example_CallFlashAPI(void);

#pragma CODE_SECTION(writeFlashAPI,ramFuncSection);
void writeFlashAPI(void);
